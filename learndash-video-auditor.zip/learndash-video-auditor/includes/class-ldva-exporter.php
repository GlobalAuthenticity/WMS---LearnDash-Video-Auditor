<?php
defined('ABSPATH') || exit;

final class LDVA_Exporter {
    public static function filter(array $rows, array $filters): array {
        $platform = sanitize_text_field($filters['platform'] ?? '');
        $status = sanitize_text_field($filters['status'] ?? '');
        $search = strtolower(sanitize_text_field($filters['search'] ?? ''));
        return array_values(array_filter($rows, static function ($row) use ($platform, $status, $search) {
            if ($platform && $row['platform'] !== $platform) return false;
            if ($status && $row['status'] !== $status) return false;
            if ($search) {
                $haystack = strtolower(implode(' ', [$row['course'], $row['lesson'], $row['platform'], $row['url'], $row['embed'] ?? '', $row['shortcode'] ?? '', $row['status']]));
                if (strpos($haystack, $search) === false) return false;
            }
            return true;
        }));
    }

    public static function download_csv(array $rows): void {
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="auditoria-videos-' . gmdate('Y-m-d') . '.csv"');
        $out = fopen('php://output', 'wb');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, array_map([self::class, 'csv_safe'], self::headers()));
        foreach ($rows as $row) {
            fputcsv($out, array_map([self::class, 'csv_safe'], self::values($row)));
        }
        fclose($out);
        exit;
    }

    /**
     * Neutraliza CSV/Excel formula injection: prefija con comilla simple los
     * valores que comiencen con caracteres que las hojas de cálculo interpretan
     * como fórmula (=, +, -, @) o con separadores de control (tab, CR).
     */
    private static function csv_safe($value): string {
        $value = (string) $value;
        if ($value === '') {
            return $value;
        }
        if (strpos("=+-@\t\r", $value[0]) !== false) {
            return "'" . $value;
        }
        return $value;
    }

    public static function download_xlsx(array $rows, bool $course_report = false): void {
        if (!class_exists('ZipArchive')) {
            wp_die(esc_html__('La extensión PHP ZipArchive es necesaria para exportar XLSX. Utilice CSV.', 'ld-video-auditor'));
        }
        $tmp = wp_tempnam('ldva.xlsx');
        $zip = new ZipArchive();
        $zip->open($tmp, ZipArchive::OVERWRITE);
        $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>');
        $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
        $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Videos" sheetId="1" r:id="rId1"/></sheets></workbook>');
        $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
        $zip->addFromString('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font/><font><b/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf/><xf fontId="1" applyFont="1"/></cellXfs></styleSheet>');

        $headers = self::headers($course_report);
        $all = [$headers];
        foreach ($rows as $row) $all[] = self::values($row, $course_report);
        $sheet_rows = '';
        foreach ($all as $r => $values) {
            $cells = '';
            foreach ($values as $c => $value) {
                $ref = self::column($c + 1) . ($r + 1);
                $style = $r === 0 ? ' s="1"' : '';
                $cells .= '<c r="' . $ref . '" t="inlineStr"' . $style . '><is><t xml:space="preserve">' . self::xml((string) $value) . '</t></is></c>';
            }
            $sheet_rows .= '<row r="' . ($r + 1) . '">' . $cells . '</row>';
        }
        $last_column = self::column(count($headers));
        $sheet = '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols><col min="1" max="2" width="32" customWidth="1"/><col min="3" max="3" width="16" customWidth="1"/><col min="4" max="5" width="55" customWidth="1"/><col min="6" max="6" width="18" customWidth="1"/></cols><sheetData>' . $sheet_rows . '</sheetData><autoFilter ref="A1:' . $last_column . count($all) . '"/></worksheet>';
        $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);
        $zip->close();

        nocache_headers();
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        $filename = $course_report ? 'cursos-lecciones-videos-' : 'auditoria-videos-';
        header('Content-Disposition: attachment; filename="' . $filename . gmdate('Y-m-d') . '.xlsx"');
        header('Content-Length: ' . filesize($tmp));
        readfile($tmp);
        unlink($tmp);
        exit;
    }

    private static function headers(bool $course_report = false): array {
        if ($course_report) {
            return ['Nombre del curso', 'Nombre de la lección', 'Plataforma', 'Enlace del video'];
        }
        return ['Nombre del curso', 'Nombre de la lección', 'Plataforma', 'URL original del video', 'Código HTML embebido', 'Shortcode', 'Estado'];
    }
    private static function values(array $row, bool $course_report = false): array {
        if ($course_report) {
            return [$row['course'], $row['lesson'], $row['platform'], $row['url']];
        }
        return [$row['course'], $row['lesson'], $row['platform'], $row['url'], $row['embed'], $row['shortcode'] ?? '', $row['status']];
    }
    private static function xml(string $value): string {
        return htmlspecialchars(preg_replace('/[^\P{C}\t\r\n]/u', '', $value), ENT_XML1 | ENT_QUOTES, 'UTF-8');
    }
    private static function column(int $number): string {
        $name = '';
        while ($number > 0) {
            $number--;
            $name = chr(65 + ($number % 26)) . $name;
            $number = intdiv($number, 26);
        }
        return $name;
    }
}
