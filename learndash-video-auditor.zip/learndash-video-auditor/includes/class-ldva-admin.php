<?php
defined('ABSPATH') || exit;

final class LDVA_Admin {
    private static $instance;
    private string $page_hook = '';
    const TOKENS_OPTION = 'ldva_bunny_tokens';
    const NO_EXPIRE_TTL = 10 * YEAR_IN_SECONDS;
    public static function instance(): self {
        return self::$instance ?? (self::$instance = new self());
    }
    private function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('current_screen', [$this, 'suppress_foreign_notices']);
        add_action('init', [$this, 'register_bunny_shortcode'], 20);
        add_action('admin_enqueue_scripts', [$this, 'assets']);
        add_action('wp_enqueue_scripts', [$this, 'public_assets']);
        add_action('wp_ajax_ldva_scan', [$this, 'ajax_scan']);
        add_action('wp_ajax_ldva_save_video', [$this, 'ajax_save_video']);
        add_action('wp_ajax_ldva_remove_video', [$this, 'ajax_remove_video']);
        add_action('wp_ajax_ldva_mark_video_watched', [$this, 'ajax_mark_video_watched']);
        add_action('wp_ajax_ldva_save_bunny_tokens', [$this, 'ajax_save_bunny_tokens']);
        add_action('wp_ajax_ldva_delete_bunny_token', [$this, 'ajax_delete_bunny_token']);
        add_action('admin_post_ldva_export', [$this, 'export']);
        add_filter('the_content', [$this, 'append_managed_embed'], 20);
        add_filter('the_content', [$this, 'resign_bunny_embeds'], 30);
        add_filter('learndash_process_mark_complete', [$this, 'gate_mark_complete'], 10, 4);
    }
    public function menu(): void {
        $this->page_hook = add_submenu_page(
            'learndash-lms',
            __('Auditor de videos', 'ld-video-auditor'),
            __('Auditor de videos', 'ld-video-auditor'),
            'manage_options',
            'ld-video-auditor',
            [$this, 'page']
        );
    }
    /**
     * Oculta los admin_notices de otros plugins (avisos de actualización,
     * banners de terceros, etc.) únicamente en la pantalla del Auditor de
     * videos, para mantenerla limpia. No afecta a ninguna otra pantalla del
     * admin ni a los notices generados por nuestro propio plugin, que se
     * imprimen directamente en la plantilla y no usan estos hooks.
     */
    public function suppress_foreign_notices(): void {
        $screen = get_current_screen();
        if (!$screen || !$this->page_hook || $screen->id !== $this->page_hook) {
            return;
        }
        remove_all_actions('admin_notices');
        remove_all_actions('all_admin_notices');
    }
    public function assets(string $hook): void {
        if (strpos($hook, 'ld-video-auditor') === false) return;
        wp_enqueue_style('ldva-admin', LDVA_URL . 'assets/admin.css', [], LDVA_VERSION);
        wp_enqueue_script('ldva-admin', LDVA_URL . 'assets/admin.js', [], LDVA_VERSION, true);
        wp_localize_script('ldva-admin', 'LDVA', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'exportUrl' => admin_url('admin-post.php'),
            'nonce' => wp_create_nonce('ldva_nonce'),
            'exportNonce' => wp_create_nonce('ldva_export'),
            'bunnyTokens' => self::bunny_tokens(),
            'strings' => [
                'loading' => __('Analizando las lecciones…', 'ld-video-auditor'),
                'empty' => __('Este curso no contiene lecciones.', 'ld-video-auditor'),
                'error' => __('No fue posible cargar los datos.', 'ld-video-auditor'),
                'copied' => __('Copiado', 'ld-video-auditor'),
                'copy' => __('Copiar', 'ld-video-auditor'),
                'saving' => __('Guardando…', 'ld-video-auditor'),
                'saved' => __('Video actualizado correctamente.', 'ld-video-auditor'),
                'removeConfirm' => __('¿Seguro que deseas remover este video de la lección?', 'ld-video-auditor'),
                'removing' => __('Removiendo…', 'ld-video-auditor'),
                'viewLesson' => __('Ver lección', 'ld-video-auditor'),
                'removeVideo' => __('Remover video', 'ld-video-auditor'),
                'editVideo' => __('Editar video', 'ld-video-auditor'),
                'addVideo' => __('Añadir video', 'ld-video-auditor'),
                'actions' => __('Acciones', 'ld-video-auditor'),
                'noResults' => __('No hay resultados para los filtros actuales.', 'ld-video-auditor'),
                'selectCourse' => __('Seleccione un curso para comenzar.', 'ld-video-auditor'),
                'resultSingular' => __('resultado', 'ld-video-auditor'),
                'resultPlural' => __('resultados', 'ld-video-auditor'),
                'total' => __('total', 'ld-video-auditor'),
                'tokenSaving' => __('Guardando…', 'ld-video-auditor'),
                'tokenSaved' => __('Configuración de token guardada.', 'ld-video-auditor'),
                'tokenError' => __('No fue posible guardar la configuración.', 'ld-video-auditor'),
                'tokenRemoveRow' => __('Quitar', 'ld-video-auditor'),
                'tokenLibraryRequired' => __('Cada fila necesita un ID de biblioteca y una clave.', 'ld-video-auditor'),
                'tokenEmpty' => __('No hay bibliotecas configuradas. Use "Añadir biblioteca" para crear una.', 'ld-video-auditor'),
                'tokenDeleteConfirm' => __('¿Eliminar este token de la biblioteca de forma permanente?', 'ld-video-auditor'),
                'tokenDeleted' => __('Token eliminado.', 'ld-video-auditor'),
            ],
        ]);
    }
    public function public_assets(): void {
        if (is_singular('sfwd-lessons')) {
            wp_enqueue_style('ldva-public', LDVA_URL . 'assets/public.css', [], LDVA_VERSION);
            wp_enqueue_script(
                'ldva-bunny-playerjs',
                'https://assets.mediadelivery.net/playerjs/playerjs-latest.min.js',
                [],
                null,
                true
            );
            wp_enqueue_script(
                'ldva-bunny-progression',
                LDVA_URL . 'assets/bunny-progression.js',
                ['ldva-bunny-playerjs'],
                LDVA_VERSION,
                true
            );
            $lesson_id = (int) get_queried_object_id();
            $user_id = get_current_user_id();
            $watched = $user_id ? (array) get_user_meta($user_id, self::watched_meta_key($lesson_id), true) : [];
            wp_localize_script('ldva-bunny-progression', 'LDVABunny', [
                'lessonId' => $lesson_id,
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('ldva_progression'),
                'watched' => array_values(array_filter(array_map('strval', $watched))),
                'waitingText' => __('Debes terminar de ver el video para marcarlo como completado y continuar.', 'ld-video-auditor'),
                'readyText' => __('Video completado. Ya puedes marcar la lección como completada.', 'ld-video-auditor'),
                'errorText' => __('No se pudo registrar el avance del video. Recarga la página e inténtalo de nuevo.', 'ld-video-auditor'),
            ]);
        }
    }
    public function page(): void {
        if (!current_user_can('manage_options')) return;
        $courses = LDVA_Scanner::courses();
        include LDVA_DIR . 'views/admin-page.php';
    }

    /**
     * Configuración guardada de "Embed View Token Authentication" de Bunny
     * Stream, por biblioteca: [['library' => '123', 'key' => '...', 'expires' => 3600], ...].
     */
    public static function bunny_tokens(): array {
        $tokens = get_option(self::TOKENS_OPTION, []);
        if (!is_array($tokens)) return [];
        return array_values(array_filter($tokens, static function ($row) {
            return is_array($row) && !empty($row['library']) && !empty($row['key']);
        }));
    }

    private static function bunny_token_config(string $library): ?array {
        foreach (self::bunny_tokens() as $row) {
            if ((string) $row['library'] === $library) return $row;
        }
        return null;
    }

    /**
     * Firma un embed de Bunny Stream según el algoritmo de "Embed View Token
     * Authentication": token = SHA256_HEX(security_key + video_id + expires).
     * Devuelve [] si la biblioteca no tiene una clave configurada.
     */
    public static function sign_bunny_embed(string $library, string $video_id): array {
        $config = self::bunny_token_config($library);
        if (!$config) return [];
        $ttl = (int) ($config['expires'] ?? 0);
        $expires = time() + ($ttl > 0 ? $ttl : 3600);
        return [
            'token' => hash('sha256', $config['key'] . $video_id . $expires),
            'expires' => $expires,
        ];
    }

    public function ajax_save_bunny_tokens(): void {
        check_ajax_referer('ldva_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Sin permisos.', 'ld-video-auditor')], 403);
        }
        $raw = json_decode((string) wp_unslash($_POST['tokens'] ?? '[]'), true);
        if (!is_array($raw)) {
            wp_send_json_error(['message' => __('Datos de token inválidos.', 'ld-video-auditor')], 400);
        }

        $clean = [];
        foreach ($raw as $row) {
            if (!is_array($row)) continue;
            $library = preg_replace('/\D+/', '', (string) ($row['library'] ?? ''));
            $key = trim((string) ($row['key'] ?? ''));
            if ($library === '' || $key === '') continue;
            $no_expire = !empty($row['no_expire']);
            $expires = $no_expire ? self::NO_EXPIRE_TTL : absint($row['expires'] ?? 0);
            $clean[$library] = [
                'library' => $library,
                'key' => $key,
                'expires' => $no_expire ? self::NO_EXPIRE_TTL : min(max($expires ?: 3600, 60), self::NO_EXPIRE_TTL),
                'no_expire' => $no_expire,
            ];
        }

        update_option(self::TOKENS_OPTION, array_values($clean), false);
        wp_send_json_success([
            'message' => __('Configuración de token guardada.', 'ld-video-auditor'),
            'tokens' => array_values($clean),
        ]);
    }

    /**
     * Elimina de inmediato, en la base de datos, el token de una sola
     * biblioteca (usado por el botón de papelera de cada fila), sin esperar
     * al guardado en lote de "Guardar tokens".
     */
    public function ajax_delete_bunny_token(): void {
        check_ajax_referer('ldva_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Sin permisos.', 'ld-video-auditor')], 403);
        }
        $library = preg_replace('/\D+/', '', (string) wp_unslash($_POST['library'] ?? ''));
        if ($library === '') {
            wp_send_json_error(['message' => __('ID de biblioteca no válido.', 'ld-video-auditor')], 400);
        }
        $remaining = array_values(array_filter(self::bunny_tokens(), static function ($row) use ($library) {
            return (string) $row['library'] !== $library;
        }));
        update_option(self::TOKENS_OPTION, $remaining, false);
        wp_send_json_success([
            'message' => __('Token eliminado.', 'ld-video-auditor'),
            'tokens' => $remaining,
        ]);
    }
    public function ajax_scan(): void {
        check_ajax_referer('ldva_nonce', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Forbidden'], 403);
        $course_id = absint($_POST['course_id'] ?? 0);
        wp_send_json_success(['rows' => LDVA_Scanner::scan_course($course_id)]);
    }
    public function ajax_save_video(): void {
        check_ajax_referer('ldva_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Sin permisos.', 'ld-video-auditor')], 403);
        }

        $lesson_id = absint($_POST['lesson_id'] ?? 0);
        if (!$lesson_id || get_post_type($lesson_id) !== 'sfwd-lessons') {
            wp_send_json_error(['message' => __('La lección no es válida.', 'ld-video-auditor')], 400);
        }

        $url = esc_url_raw(trim(wp_unslash($_POST['video_url'] ?? '')));
        $raw_embed = trim(wp_unslash($_POST['video_embed'] ?? ''));
        if (strlen($raw_embed) >= 2 && $raw_embed[0] === '"' && substr($raw_embed, -1) === '"') {
            $raw_embed = substr($raw_embed, 1, -1);
        }
        $embed = wp_kses($raw_embed, self::allowed_embed_html());
        $shortcode = trim(wp_unslash($_POST['video_shortcode'] ?? ''));
        $old_url = esc_url_raw(trim(wp_unslash($_POST['original_url'] ?? '')));
        $old_embed = trim(wp_unslash($_POST['original_embed'] ?? ''));
        if ($raw_embed !== '' && $embed === '') {
            wp_send_json_error(['message' => __('El HTML embebido no contiene un iframe permitido.', 'ld-video-auditor')], 400);
        }

        if ($url !== '' && !LDVA_Scanner::is_supported_video_url($url)) {
            wp_send_json_error(['message' => __('La URL debe pertenecer a YouTube, Vimeo o Bunny Stream.', 'ld-video-auditor')], 400);
        }
        $is_bunny = $url !== '' && LDVA_Scanner::is_bunny_url($url);
        $bunny_source = $is_bunny ? $url : self::iframe_source($embed);
        if ($bunny_source !== '') {
            $is_bunny = true;
            if ($shortcode === '') {
                $shortcode = self::bunny_shortcode_from_url($bunny_source);
                if ($shortcode === '') {
                    wp_send_json_error(['message' => __('No fue posible generar el shortcode de Bunny Stream a partir de esa URL o iframe. Revise que la URL de biblioteca/ID sea válida.', 'ld-video-auditor')], 400);
                }
            }
            // Para Bunny, el video en la lección siempre queda como shortcode
            // (nunca como iframe suelto): es la única forma con la que el
            // token de "Embed View Token Authentication" se recalcula en
            // cada visita en vez de quedar firmado con una fecha fija.
            $embed = '';
        }
        if ($embed !== '' && !LDVA_Scanner::contains_supported_video($embed)) {
            wp_send_json_error(['message' => __('El iframe debe pertenecer a YouTube, Vimeo o Bunny Stream.', 'ld-video-auditor')], 400);
        }
        if ($shortcode !== '' && !preg_match('/^\s*\[[A-Za-z0-9_-]+(?:\s|\]|\/)/', $shortcode)) {
            wp_send_json_error(['message' => __('El shortcode no tiene un formato válido.', 'ld-video-auditor')], 400);
        }
        if ($shortcode !== '' && !self::shortcode_contains_supported_video($shortcode)) {
            wp_send_json_error(['message' => __('El shortcode debe contener o generar un video de YouTube, Vimeo o Bunny Stream.', 'ld-video-auditor')], 400);
        }

        $replaced_content = false;
        $replacement = $shortcode !== '' ? $shortcode : ($embed !== '' ? $embed : $url);
        $post = get_post($lesson_id);
        if ($post) {
            $updated_content = $post->post_content;
            if ($old_embed !== '' && strpos($updated_content, $old_embed) !== false) {
                $updated_content = str_replace($old_embed, $replacement, $updated_content);
            } elseif ($old_url !== '' && strpos($updated_content, $old_url) !== false) {
                $updated_content = str_replace($old_url, $replacement, $updated_content);
            }
            if ($updated_content === $post->post_content && $old_url !== '') {
                $updated_content = self::replace_video_by_id(
                    $updated_content,
                    $old_url,
                    $replacement
                );
            }
            if ($updated_content !== $post->post_content) {
                $result = wp_update_post(['ID' => $lesson_id, 'post_content' => $updated_content], true);
                if (is_wp_error($result)) {
                    wp_send_json_error(['message' => $result->get_error_message()], 500);
                }
                $replaced_content = true;
            }
        }

        $settings = get_post_meta($lesson_id, '_sfwd-lessons', true);
        $settings = is_array($settings) ? $settings : [];
        $current_ld_url = (string) ($settings['sfwd-lessons_lesson_video_url'] ?? '');
        $editing_ld_video = $old_url !== '' && $current_ld_url !== ''
            && LDVA_Scanner::video_key($old_url) === LDVA_Scanner::video_key($current_ld_url);
        if ($editing_ld_video || (!$replaced_content && $old_embed === '' && $embed === '')) {
            $settings['sfwd-lessons_lesson_video_url'] = $shortcode !== '' || $is_bunny ? '' : $url;
            update_post_meta($lesson_id, '_sfwd-lessons', $settings);
            if (function_exists('learndash_update_setting')) {
                learndash_update_setting($lesson_id, 'lesson_video_url', $shortcode !== '' || $is_bunny ? '' : $url);
            }
        }

        delete_post_meta($lesson_id, '_ldva_video_url');
        delete_post_meta($lesson_id, '_ldva_video_embed');
        delete_post_meta($lesson_id, '_ldva_video_shortcode');
        if (!$replaced_content && (!$editing_ld_video || $is_bunny || $shortcode !== '')) {
            if ($shortcode !== '') {
                update_post_meta($lesson_id, '_ldva_video_shortcode', $shortcode);
            } else {
                if ($url !== '') update_post_meta($lesson_id, '_ldva_video_url', $url);
                if ($embed !== '') update_post_meta($lesson_id, '_ldva_video_embed', $embed);
            }
        }
        clean_post_cache($lesson_id);
        wp_send_json_success(['message' => __('Video actualizado correctamente.', 'ld-video-auditor')]);
    }
    private static function replace_video_by_id(string $content, string $old_url, string $replacement): string {
        $key = LDVA_Scanner::video_key($old_url);
        $parts = explode(':', $key, 2);
        if (count($parts) !== 2 || $parts[1] === '') return $content;
        $id = preg_quote($parts[1], '~');

        $iframe_pattern = '~<iframe\b[^>]*\bsrc\s*=\s*(["\'])[^"\']*' . $id . '[^"\']*\1[^>]*>(?:\s*</iframe>)?~is';
        if (preg_match($iframe_pattern, $content)) {
            $result = preg_replace($iframe_pattern, addcslashes($replacement, '\\$'), $content, 1);
            return $result !== null ? $result : $content;
        }

        $url_pattern = '~https?://[^\s<>"\']*' . $id . '[^\s<>"\']*~i';
        $result = preg_replace($url_pattern, addcslashes($replacement, '\\$'), $content, 1);
        return $result !== null ? $result : $content;
    }
    private static function iframe_source(string $embed): string {
        if (preg_match('~<iframe\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1~is', $embed, $match)) {
            $src = html_entity_decode($match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            return LDVA_Scanner::is_bunny_url($src) ? esc_url_raw($src) : '';
        }
        return '';
    }
    private static function bunny_details(string $url): array {
        $parts = wp_parse_url(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $host = strtolower((string) ($parts['host'] ?? ''));
        $path = trim((string) ($parts['path'] ?? ''), '/');
        if (($host === 'player.mediadelivery.net' || $host === 'iframe.mediadelivery.net')
            && preg_match('~embed/(\d+)/([a-f0-9-]{20,})~i', $path, $match)) {
            return ['library' => $match[1], 'id' => strtolower($match[2])];
        }
        if ($host === 'dash.bunny.net' && preg_match('~stream/(\d+)/~i', $path, $match)) {
            parse_str((string) ($parts['query'] ?? ''), $query);
            $id = sanitize_text_field($query['vid'] ?? '');
            if (preg_match('/^[a-f0-9-]{20,}$/i', $id)) {
                return ['library' => $match[1], 'id' => strtolower($id)];
            }
        }
        return [];
    }
    private static function bunny_shortcode_from_url(string $url): string {
        $details = self::bunny_details($url);
        if (!$details) return '';
        return sprintf(
            '[bunnycdn_stream_video library="%s" id="%s" tokenAuth="true" responsive="true"]',
            $details['library'],
            $details['id']
        );
    }
    public function register_bunny_shortcode(): void {
        if (!shortcode_exists('bunnycdn_stream_video')) {
            add_shortcode('bunnycdn_stream_video', [$this, 'render_bunny_shortcode']);
        }
    }
    public function render_bunny_shortcode($atts): string {
        $atts = shortcode_atts([
            'library' => '',
            'id' => '',
            'tokenAuth' => 'true',
            'responsive' => 'true',
        ], (array) $atts, 'bunnycdn_stream_video');
        $library = preg_replace('/\D+/', '', (string) $atts['library']);
        $id = strtolower(sanitize_text_field((string) $atts['id']));
        if ($library === '' || !preg_match('/^[a-f0-9-]{20,}$/i', $id)) return '';
        $query = ['responsive' => 'true'];
        if (strtolower((string) $atts['tokenAuth']) !== 'false') {
            $signed = self::sign_bunny_embed($library, $id);
            if ($signed) $query += $signed;
        }
        $src = 'https://player.mediadelivery.net/embed/' . rawurlencode($library) . '/' . rawurlencode($id) . '?' . http_build_query($query);
        return '<iframe src="' . esc_url($src) . '" loading="lazy" style="border:0;position:absolute;top:0;height:100%;width:100%;" allow="accelerometer;gyroscope;autoplay;encrypted-media;picture-in-picture;fullscreen" allowfullscreen="true"></iframe>';
    }
    private static function shortcode_contains_supported_video(string $shortcode): bool {
        $probe = html_entity_decode($shortcode . ' ' . do_shortcode(shortcode_unautop($shortcode)), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (LDVA_Scanner::contains_supported_video($probe)) return true;
        if (preg_match_all('~https?://[^\s<>"\'\]]+~i', $probe, $matches)) {
            foreach ($matches[0] as $candidate) {
                if (LDVA_Scanner::is_supported_video_url(rtrim($candidate, '.,;)'))) return true;
            }
        }
        return false;
    }
    public function ajax_remove_video(): void {
        check_ajax_referer('ldva_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Sin permisos.', 'ld-video-auditor')], 403);
        }
        $lesson_id = absint($_POST['lesson_id'] ?? 0);
        $url = esc_url_raw(trim(wp_unslash($_POST['video_url'] ?? '')));
        $embed = trim(wp_unslash($_POST['video_embed'] ?? ''));
        $shortcode = trim(wp_unslash($_POST['video_shortcode'] ?? ''));
        if (!$lesson_id || get_post_type($lesson_id) !== 'sfwd-lessons' || $url === '') {
            wp_send_json_error(['message' => __('El registro de video no es válido.', 'ld-video-auditor')], 400);
        }

        $post = get_post($lesson_id);
        if ($post) {
            $content = $shortcode !== '' ? str_replace($shortcode, '', $post->post_content) : $post->post_content;
            $content = self::remove_video_from_content($content, $url, $embed);
            if ($content !== $post->post_content) {
                $result = wp_update_post(['ID' => $lesson_id, 'post_content' => $content], true);
                if (is_wp_error($result)) {
                    wp_send_json_error(['message' => $result->get_error_message()], 500);
                }
            }
        }

        $target_key = LDVA_Scanner::video_key($url);
        $settings = get_post_meta($lesson_id, '_sfwd-lessons', true);
        $settings = is_array($settings) ? $settings : [];
        $ld_url = (string) ($settings['sfwd-lessons_lesson_video_url'] ?? '');
        if ($ld_url !== '' && LDVA_Scanner::video_key($ld_url) === $target_key) {
            $settings['sfwd-lessons_lesson_video_url'] = '';
            update_post_meta($lesson_id, '_sfwd-lessons', $settings);
            if (function_exists('learndash_update_setting')) {
                learndash_update_setting($lesson_id, 'lesson_video_url', '');
            }
        }

        foreach (['_ldva_video_url', '_ldva_video_embed', '_ldva_video_shortcode'] as $meta_key) {
            $value = (string) get_post_meta($lesson_id, $meta_key, true);
            if ($value !== '' && (($meta_key === '_ldva_video_shortcode' && $shortcode !== '' && $value === $shortcode) || self::value_contains_video_key($value, $target_key))) {
                delete_post_meta($lesson_id, $meta_key);
            }
        }
        self::remove_video_from_all_meta($lesson_id, $url, $embed);
        clean_post_cache($lesson_id);
        wp_send_json_success(['message' => __('Video removido correctamente.', 'ld-video-auditor')]);
    }
    private static function remove_video_from_content(string $content, string $url, string $embed): string {
        if ($embed !== '') {
            $content = str_replace($embed, '', $content);
        }
        $key = LDVA_Scanner::video_key($url);
        $parts = explode(':', $key, 2);
        if (count($parts) !== 2 || $parts[1] === '') {
            return str_replace($url, '', $content);
        }
        $id = preg_quote($parts[1], '~');
        $wrapped_pattern = '~<div\b[^>]*>\s*<iframe\b[^>]*\bsrc\s*=\s*(["\'])[^"\']*' . $id . '[^"\']*\1[^>]*>(?:\s*</iframe>)?\s*</div>~is';
        $iframe_pattern = '~<iframe\b[^>]*\bsrc\s*=\s*(["\'])[^"\']*' . $id . '[^"\']*\1[^>]*>(?:\s*</iframe>)?~is';
        $url_pattern = '~https?://[^\s<>"\']*' . $id . '[^\s<>"\']*~i';
        $step1 = preg_replace($wrapped_pattern, '', $content);
        $step2 = preg_replace($iframe_pattern, '', $step1 !== null ? $step1 : $content);
        $step3 = preg_replace($url_pattern, '', $step2 !== null ? $step2 : $content);
        return $step3 !== null ? $step3 : $content;
    }
    private static function value_contains_video_key(string $value, string $target_key): bool {
        if (preg_match_all('~https?://[^\s<>"\']+~i', html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'), $matches)) {
            foreach ($matches[0] as $candidate) {
                if (LDVA_Scanner::video_key($candidate) === $target_key) return true;
            }
        }
        return false;
    }
    private static function remove_video_from_all_meta(int $lesson_id, string $url, string $embed): void {
        $key_parts = explode(':', LDVA_Scanner::video_key($url), 2);
        if (count($key_parts) !== 2 || $key_parts[1] === '') return;
        $video_id = $key_parts[1];
        $all_meta = get_post_meta($lesson_id);

        foreach (array_keys($all_meta) as $meta_key) {
            if (in_array($meta_key, ['_edit_lock', '_edit_last'], true)) continue;
            $values = get_post_meta($lesson_id, $meta_key, false);
            foreach ($values as $old_value) {
                if (strpos(maybe_serialize($old_value), $video_id) === false) continue;
                $new_value = self::clean_video_from_value($old_value, $url, $embed);
                if ($new_value !== $old_value) {
                    update_post_meta($lesson_id, $meta_key, $new_value, $old_value);
                }
            }
        }
    }
    private static function clean_video_from_value($value, string $url, string $embed) {
        if (is_string($value)) {
            return self::remove_video_from_content($value, $url, $embed);
        }
        if (is_array($value)) {
            foreach ($value as $key => $nested) {
                $value[$key] = self::clean_video_from_value($nested, $url, $embed);
            }
            return $value;
        }
        if (is_object($value)) {
            $copy = clone $value;
            foreach (get_object_vars($copy) as $key => $nested) {
                $copy->{$key} = self::clean_video_from_value($nested, $url, $embed);
            }
            return $copy;
        }
        return $value;
    }
    private static function watched_meta_key(int $lesson_id): string {
        return '_ldva_bunny_watched_' . $lesson_id;
    }

    /**
     * Registra que el usuario terminó de ver un video Bunny de la lección.
     * Valida el nonce, la sesión y que la clave pertenezca realmente a esa
     * lección, de modo que no puedan forjarse claves arbitrarias.
     */
    public function ajax_mark_video_watched(): void {
        check_ajax_referer('ldva_progression', 'nonce');
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => __('Sesión no válida.', 'ld-video-auditor')], 403);
        }
        $lesson_id = absint($_POST['lesson_id'] ?? 0);
        if (!$lesson_id || get_post_type($lesson_id) !== 'sfwd-lessons') {
            wp_send_json_error(['message' => __('La lección no es válida.', 'ld-video-auditor')], 400);
        }
        $key = LDVA_Scanner::normalize_bunny_key(wp_unslash($_POST['video_key'] ?? ''));
        if ($key === '') {
            wp_send_json_error(['message' => __('El identificador del video no es válido.', 'ld-video-auditor')], 400);
        }
        if (!in_array($key, LDVA_Scanner::bunny_video_keys($lesson_id), true)) {
            wp_send_json_error(['message' => __('El video no pertenece a esta lección.', 'ld-video-auditor')], 400);
        }

        $meta_key = self::watched_meta_key($lesson_id);
        $watched = (array) get_user_meta($user_id, $meta_key, true);
        $watched = array_values(array_filter(array_map('strval', $watched)));
        if (!in_array($key, $watched, true)) {
            $watched[] = $key;
            update_user_meta($user_id, $meta_key, $watched);
        }

        $required = LDVA_Scanner::bunny_video_keys($lesson_id);
        $remaining = array_values(array_diff($required, $watched));
        wp_send_json_success([
            'watched' => $watched,
            'remaining' => count($remaining),
            'complete' => empty($remaining),
        ]);
    }

    /**
     * Bloquea "Marcar completado" en el servidor mientras el usuario no haya
     * visto todos los videos Bunny requeridos de la lección. Devuelve false para
     * impedir la completación aunque el cliente intente forzarla.
     */
    /**
     * $course_id lleva valor por defecto porque LearnDash no siempre invoca
     * este filtro con los 4 argumentos: en ciertas rutas internas de
     * ld-course-progress.php (según versión de sfwd-lms) lo dispara solo con
     * (process, post, user), sin course_id. Con PHP 8+ eso provocaba un
     * ArgumentCountError fatal al hacer clic en "Marcar como completado".
     *
     * Además, según la ruta interna, $user puede llegar como WP_User o como
     * ID numérico: castear directamente (int) $user_id cuando es un objeto
     * generaba un warning ("Object of class WP_User could not be converted
     * to int") y el resultado del cast quedaba en 1, es decir, el gate leía
     * el avance del usuario 1 en vez del usuario real. Como ese usuario 1
     * normalmente no tiene el video marcado como visto, el gate bloqueaba
     * "Marcar completado" en silencio (sin error, solo recargaba la misma
     * lección) para cualquier usuario real.
     */
    public function gate_mark_complete($process, $post, $user_id, $course_id = 0) {
        if (!$process) {
            return $process;
        }
        $post_id = is_object($post) ? (int) $post->ID : (int) $post;
        if (!$post_id || get_post_type($post_id) !== 'sfwd-lessons') {
            return $process;
        }
        $user_id = is_object($user_id) ? (int) $user_id->ID : (int) $user_id;
        if (!$user_id || user_can($user_id, 'manage_options')) {
            return $process;
        }
        if (!apply_filters('ldva_enforce_bunny_progression', true, $post_id, $user_id)) {
            return $process;
        }

        $required = LDVA_Scanner::bunny_video_keys($post_id);
        if (!$required) {
            return $process;
        }
        $watched = (array) get_user_meta($user_id, self::watched_meta_key($post_id), true);
        $watched = array_map('strval', $watched);
        foreach ($required as $key) {
            if (!in_array($key, $watched, true)) {
                return false;
            }
        }
        return $process;
    }

    public function append_managed_embed(string $content): string {
        if (is_admin() || !is_singular('sfwd-lessons')) return $content;
        $embed = (string) get_post_meta(get_the_ID(), '_ldva_video_embed', true);
        $shortcode = (string) get_post_meta(get_the_ID(), '_ldva_video_shortcode', true);
        if ($embed !== '') {
            $content .= '<div class="ldva-lesson-video">' . wp_kses($embed, self::allowed_embed_html()) . '</div>';
        }
        if ($shortcode !== '') {
            $content .= '<div class="ldva-lesson-video ldva-shortcode-video">' . do_shortcode(shortcode_unautop($shortcode)) . '</div>';
        }
        return $content;
    }

    /**
     * Pasada final sobre el HTML ya ensamblado de la lección: firma (o
     * refirma) cualquier URL de embed de Bunny Stream que aparezca en el
     * contenido, sin importar si llegó desde post_content (video pegado a
     * mano o por versiones anteriores del plugin), desde la meta
     * _ldva_video_embed (que sin esto quedaría firmada una sola vez, en el
     * momento de guardarla, y luego expiraría) o desde el propio shortcode
     * (que ya se recalcula solo, pero no está de más). Así el token siempre
     * corresponde al momento de la visita, y solo actúa sobre bibliotecas
     * que tengan una clave configurada; el resto queda intacto.
     */
    public function resign_bunny_embeds(string $content): string {
        if (is_admin() || !is_singular('sfwd-lessons') || strpos($content, 'mediadelivery.net/embed/') === false) {
            return $content;
        }
        if (!self::bunny_tokens()) {
            return $content;
        }
        $result = preg_replace_callback(
            '~https://(?:player|iframe)\.mediadelivery\.net/embed/(\d+)/([a-f0-9-]{20,})(\?[^"\'\s<>]*)?~i',
            static function (array $match): string {
                $library = $match[1];
                $video_id = strtolower($match[2]);
                $signed = self::sign_bunny_embed($library, $video_id);
                if (!$signed) {
                    return $match[0];
                }
                $params = [];
                if (!empty($match[3])) {
                    parse_str(ltrim($match[3], '?'), $params);
                }
                unset($params['token'], $params['expires']);
                $params += $signed;
                return 'https://player.mediadelivery.net/embed/' . rawurlencode($library) . '/' . rawurlencode($video_id) . '?' . http_build_query($params);
            },
            $content
        );
        // preg_replace_callback() devuelve null si el motor de PCRE falla
        // (p. ej. se excede pcre.backtrack_limit en contenido muy grande, algo
        // común en lecciones armadas con Elementor). Como este método está
        // colgado en el filtro the_content, devolver null en vez de string
        // provoca un TypeError fatal que tumba toda la página. Ante ese caso
        // se prefiere mostrar el contenido sin refirmar antes que romper la
        // lección completa.
        return $result !== null ? $result : $content;
    }
    private static function allowed_embed_html(): array {
        return [
            'div' => [
                'class' => true, 'style' => true,
            ],
            'iframe' => [
                'src' => true, 'width' => true, 'height' => true, 'title' => true,
                'frameborder' => true, 'allow' => true, 'allowfullscreen' => true,
                'loading' => true, 'referrerpolicy' => true, 'class' => true,
                'style' => true,
            ],
        ];
    }
    public function export(): void {
        check_admin_referer('ldva_export', 'nonce');
        if (!current_user_can('manage_options')) wp_die(esc_html__('Sin permisos.', 'ld-video-auditor'));
        if (sanitize_key($_GET['scope'] ?? '') === 'all') {
            $rows = [];
            foreach (LDVA_Scanner::courses() as $course) {
                foreach (LDVA_Scanner::scan_course((int) $course->ID) as $row) {
                    if ($row['status'] === 'Encontrado' && $row['url'] !== '') {
                        $rows[] = $row;
                    }
                }
            }
            LDVA_Exporter::download_xlsx($rows, true);
        }
        $course_id = absint($_GET['course_id'] ?? 0);
        $rows = LDVA_Exporter::filter(LDVA_Scanner::scan_course($course_id), wp_unslash($_GET));
        if (sanitize_key($_GET['format'] ?? 'csv') === 'xlsx') LDVA_Exporter::download_xlsx($rows);
        LDVA_Exporter::download_csv($rows);
    }
}
