(() => {
  'use strict';
  const $ = (s) => document.querySelector(s);

  const tokenRows = $('#ldva-token-rows');
  if (tokenRows) {
    const addRowBtn = $('#ldva-token-add');
    const saveBtn = $('#ldva-token-save');
    const message = $('#ldva-token-message');

    const addRow = (data = {}) => {
      removeEmptyState();
      const row = document.createElement('div');
      row.className = 'ldva-token-row';
      row.dataset.savedLibrary = data.library ? String(data.library) : '';
      row.innerHTML = `
        <div class="ldva-field">
          <label>ID de biblioteca</label>
          <input type="text" inputmode="numeric" class="ldva-token-library" placeholder="123" value="${data.library ? String(data.library).replace(/"/g, '&quot;') : ''}">
        </div>
        <div class="ldva-field">
          <label>Token key</label>
          <input type="password" class="ldva-token-key code" placeholder="Embed View Token Authentication Key" value="${data.key ? String(data.key).replace(/"/g, '&quot;') : ''}">
        </div>
        <div class="ldva-field">
          <label>Expiración (s)</label>
          <input type="number" min="60" class="ldva-token-expires" placeholder="3600" value="${data.expires && !data.no_expire ? Number(data.expires) : ''}" ${data.no_expire ? 'disabled' : ''}>
        </div>
        <div class="ldva-field ldva-token-no-expire-field">
          <label aria-hidden="true">&nbsp;</label>
          <label class="ldva-token-no-expire">
            <input type="checkbox" class="ldva-token-no-expire-check" ${data.no_expire ? 'checked' : ''}>
            No expira
          </label>
        </div>
        <button type="button" class="button button-small ldva-token-remove" aria-label="${LDVA.strings.tokenRemoveRow}">
          <span class="dashicons dashicons-trash" aria-hidden="true"></span>
        </button>`;
      tokenRows.appendChild(row);
      const expiresInput = row.querySelector('.ldva-token-expires');
      const noExpireCheck = row.querySelector('.ldva-token-no-expire-check');
      noExpireCheck.addEventListener('change', () => {
        expiresInput.disabled = noExpireCheck.checked;
        if (noExpireCheck.checked) expiresInput.value = '';
      });
    };

    function removeEmptyState() {
      const empty = tokenRows.querySelector('.ldva-token-empty');
      if (empty) empty.remove();
    }

    function toggleEmptyState() {
      if (tokenRows.querySelector('.ldva-token-row')) {
        removeEmptyState();
        return;
      }
      if (!tokenRows.querySelector('.ldva-token-empty')) {
        const empty = document.createElement('p');
        empty.className = 'ldva-token-empty';
        empty.textContent = LDVA.strings.tokenEmpty;
        tokenRows.appendChild(empty);
      }
    }

    (LDVA.bunnyTokens || []).forEach(addRow);
    if (!(LDVA.bunnyTokens || []).length) addRow();

    addRowBtn.addEventListener('click', () => addRow());
    tokenRows.addEventListener('click', async (event) => {
      const remove = event.target.closest('.ldva-token-remove');
      if (!remove) return;
      const row = remove.closest('.ldva-token-row');
      const savedLibrary = row.dataset.savedLibrary;

      // Fila que aún no existe en la base de datos (recién añadida o nunca
      // guardada): basta con quitarla de la pantalla, no hay nada que borrar.
      if (!savedLibrary) {
        row.remove();
        toggleEmptyState();
        return;
      }

      if (!window.confirm(LDVA.strings.tokenDeleteConfirm)) return;
      remove.disabled = true;
      const body = new URLSearchParams({action: 'ldva_delete_bunny_token', nonce: LDVA.nonce, library: savedLibrary});
      try {
        const response = await fetch(LDVA.ajaxUrl, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body});
        const data = await response.json();
        if (!data.success) throw new Error(data.data?.message || LDVA.strings.tokenError);
        LDVA.bunnyTokens = data.data.tokens || [];
        row.remove();
        toggleEmptyState();
        message.textContent = data.data.message || LDVA.strings.tokenDeleted;
        message.className = 'ldva-modal-message is-success';
      } catch (error) {
        remove.disabled = false;
        message.textContent = error.message || LDVA.strings.tokenError;
        message.className = 'ldva-modal-message is-error';
      }
    });

    saveBtn.addEventListener('click', async () => {
      const rows = [...tokenRows.querySelectorAll('.ldva-token-row')].map((row) => ({
        library: row.querySelector('.ldva-token-library').value.trim(),
        key: row.querySelector('.ldva-token-key').value.trim(),
        expires: row.querySelector('.ldva-token-expires').value.trim(),
        no_expire: row.querySelector('.ldva-token-no-expire-check').checked,
      })).filter((row) => row.library || row.key);

      if (rows.some((row) => !row.library || !row.key)) {
        message.textContent = LDVA.strings.tokenLibraryRequired;
        message.className = 'ldva-modal-message is-error';
        return;
      }

      saveBtn.disabled = true;
      message.textContent = LDVA.strings.tokenSaving;
      message.className = 'ldva-modal-message';
      const body = new URLSearchParams({
        action: 'ldva_save_bunny_tokens',
        nonce: LDVA.nonce,
        tokens: JSON.stringify(rows),
      });
      try {
        const response = await fetch(LDVA.ajaxUrl, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body});
        const data = await response.json();
        if (!data.success) throw new Error(data.data?.message || LDVA.strings.tokenError);
        message.textContent = data.data.message || LDVA.strings.tokenSaved;
        message.className = 'ldva-modal-message is-success';
        LDVA.bunnyTokens = data.data.tokens || rows;
        tokenRows.querySelectorAll('.ldva-token-row').forEach((row) => {
          row.dataset.savedLibrary = row.querySelector('.ldva-token-library').value.trim();
        });
      } catch (error) {
        message.textContent = error.message || LDVA.strings.tokenError;
        message.className = 'ldva-modal-message is-error';
      } finally {
        saveBtn.disabled = false;
      }
    });
  }

  const course = $('#ldva-course');
  if (!course) return;
  const tbody = $('#ldva-table tbody');
  const summary = $('#ldva-summary');
  const search = $('#ldva-search');
  const platform = $('#ldva-platform');
  const status = $('#ldva-status');
  const modal = $('#ldva-modal');
  const modalLesson = $('#ldva-modal-lesson');
  const editLessonId = $('#ldva-edit-lesson-id');
  const editUrl = $('#ldva-edit-url');
  const editEmbed = $('#ldva-edit-embed');
  const editShortcode = $('#ldva-edit-shortcode');
  const modalMessage = $('#ldva-modal-message');
  const saveVideo = $('#ldva-save-video');
  let rows = [];
  let editingRow = null;

  const esc = (value) => {
    const div = document.createElement('div');
    div.textContent = value == null ? '' : String(value);
    // innerHTML escapa & < > pero no comillas; sin esto, un valor con comillas
    // (p. ej. un shortcode con library="..." o un iframe con atributos entre
    // comillas) rompe el atributo HTML donde se inserta (data-value, title…)
    // y el navegador solo lee hasta la primera comilla interna.
    return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };
  const copyCell = (value, kind) => value
    ? `<div class="ldva-value"><code title="${esc(value)}">${esc(value)}</code><button type="button" class="button button-small ldva-copy" data-value="${esc(value)}" aria-label="${esc(LDVA.strings.copy)} ${kind}"><span class="dashicons dashicons-admin-page" aria-hidden="true"></span>${esc(LDVA.strings.copy)}</button></div>`
    : '<span class="ldva-muted">—</span>';

  function videoKey(row) {
    if (!row.url) return `lesson:${row.lesson_id}:missing`;
    try {
      const parsed = new URL(row.url);
      let id = '';
      if (row.platform === 'Vimeo') {
        id = parsed.pathname.match(/(?:video\/)?(\d{6,})/)?.[1] || '';
      } else if (row.platform === 'YouTube') {
        id = parsed.hostname.includes('youtu.be')
          ? parsed.pathname.split('/').filter(Boolean)[0]
          : (parsed.searchParams.get('v') || parsed.pathname.match(/(?:embed|shorts|live)\/([A-Za-z0-9_-]{6,})/)?.[1] || '');
      } else if (row.platform === 'Bunny Stream') {
        const match = parsed.pathname.match(/embed\/(\d+)\/([a-f0-9-]{20,})/i);
        id = match ? `${match[1]}/${match[2].toLowerCase()}` : '';
      }
      return id ? `${row.lesson_id}:${row.platform}:${id}` : `${row.lesson_id}:${row.url}`;
    } catch (_) {
      return `${row.lesson_id}:${row.url}`;
    }
  }

  function dedupeRows(input) {
    const grouped = new Map();
    input.forEach((row) => {
      const key = videoKey(row);
      if (!grouped.has(key)) {
        grouped.set(key, {...row});
        return;
      }
      const current = grouped.get(key);
      if (!current.embed && row.embed) current.embed = row.embed;
      const currentIsPlayer = /player\.vimeo|\/embed\//i.test(current.url || '');
      const candidateIsDirect = /^(https?:\/\/)?(www\.)?(vimeo\.com|youtu\.be)|youtube\.com\/watch/i.test(row.url || '');
      if (currentIsPlayer && candidateIsDirect) current.url = row.url;
    });
    return [...grouped.values()];
  }

  function filtered() {
    const q = search.value.trim().toLocaleLowerCase();
    return rows.filter((row) => {
      const matchesQuery = !q || [row.course, row.lesson, row.platform, row.url, row.embed, row.shortcode, row.status].join(' ').toLocaleLowerCase().includes(q);
      return matchesQuery && (!platform.value || row.platform === platform.value) && (!status.value || row.status === status.value);
    });
  }

  function render() {
    const visible = filtered();
    const resultWord = visible.length === 1 ? LDVA.strings.resultSingular : LDVA.strings.resultPlural;
    summary.textContent = `${visible.length} ${resultWord} · ${rows.length} ${LDVA.strings.total}`;
    if (!visible.length) {
      const message = rows.length ? LDVA.strings.noResults : LDVA.strings.empty;
      tbody.innerHTML = `<tr><td colspan="8" class="ldva-empty"><span class="dashicons dashicons-search" aria-hidden="true"></span><span>${esc(message)}</span></td></tr>`;
      return;
    }
    const platformIcon = {
      YouTube: 'dashicons-youtube',
      Vimeo: 'dashicons-video-alt2',
      'Bunny Stream': 'dashicons-video-alt3'
    };
    tbody.innerHTML = visible.map((row) => `<tr>
      <td data-label="Curso"><strong>${esc(row.course)}</strong></td>
      <td data-label="Lección">${esc(row.lesson)}</td>
      <td data-label="Plataforma">${row.platform ? `<span class="ldva-platform ldva-${row.platform.toLowerCase().replace(/\s+/g, '-')}"><span class="dashicons ${platformIcon[row.platform] || 'dashicons-video-alt3'}" aria-hidden="true"></span>${esc(row.platform)}</span>` : '<span class="ldva-muted">—</span>'}</td>
      <td data-label="URL del video">${copyCell(row.url, 'URL')}</td>
      <td data-label="HTML embebido">${copyCell(row.embed, 'HTML')}</td>
      <td data-label="Shortcode">${copyCell(row.shortcode, 'shortcode')}</td>
      <td data-label="Estado"><span class="ldva-status ${row.status === 'Encontrado' ? 'is-found' : 'is-missing'}"><span class="dashicons ${row.status === 'Encontrado' ? 'dashicons-yes-alt' : 'dashicons-warning'}" aria-hidden="true"></span>${esc(row.status)}</span></td>
      <td data-label="Acciones"><div class="ldva-actions">
        <button type="button" class="button ldva-actions-toggle" data-row-index="${rows.indexOf(row)}" aria-haspopup="true" aria-expanded="false" aria-label="${esc(LDVA.strings.actions)}: ${esc(row.lesson)}">
          <span class="dashicons dashicons-ellipsis" aria-hidden="true"></span>${esc(LDVA.strings.actions)}
        </button>
        <div class="ldva-actions-menu" role="menu" hidden>
          <a class="ldva-actions-item" role="menuitem" href="${esc(row.lesson_url)}" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-external" aria-hidden="true"></span>${esc(LDVA.strings.viewLesson)}</a>
          <button type="button" class="ldva-actions-item ldva-edit" role="menuitem" data-row-index="${rows.indexOf(row)}"><span class="dashicons dashicons-edit" aria-hidden="true"></span>${row.status === 'Encontrado' ? esc(LDVA.strings.editVideo) : esc(LDVA.strings.addVideo)}</button>
          ${row.status === 'Encontrado' ? `<button type="button" class="ldva-actions-item ldva-remove" role="menuitem" data-row-index="${rows.indexOf(row)}"><span class="dashicons dashicons-trash" aria-hidden="true"></span>${esc(LDVA.strings.removeVideo)}</button>` : ''}
        </div>
      </div></td>
    </tr>`).join('');
  }

  async function load() {
    rows = [];
    if (!course.value) {
      tbody.innerHTML = `<tr><td colspan="8" class="ldva-empty"><span class="dashicons dashicons-search" aria-hidden="true"></span><span>${esc(LDVA.strings.selectCourse)}</span></td></tr>`;
      summary.textContent = LDVA.strings.selectCourse;
      return;
    }
    tbody.innerHTML = `<tr><td colspan="8" class="ldva-loading"><span class="spinner is-active" aria-hidden="true"></span>${esc(LDVA.strings.loading)}</td></tr>`;
    summary.textContent = LDVA.strings.loading;
    const body = new URLSearchParams({action: 'ldva_scan', nonce: LDVA.nonce, course_id: course.value});
    try {
      const response = await fetch(LDVA.ajaxUrl, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body});
      const data = await response.json();
      if (!data.success) throw new Error(data.data?.message || 'Error');
      rows = dedupeRows(data.data.rows || []);
      render();
    } catch (error) {
      tbody.innerHTML = `<tr><td colspan="8" class="ldva-empty ldva-empty-error"><span class="dashicons dashicons-warning" aria-hidden="true"></span><span>${esc(LDVA.strings.error)}</span></td></tr>`;
      summary.textContent = LDVA.strings.error;
    }
  }

  course.addEventListener('change', load);
  [search, platform, status].forEach((input) => input.addEventListener(input === search ? 'input' : 'change', render));
  function closeAllMenus() {
    document.querySelectorAll('.ldva-actions-menu').forEach((menu) => {
      menu.hidden = true;
      const toggle = menu.previousElementSibling;
      if (toggle) toggle.setAttribute('aria-expanded', 'false');
    });
  }

  tbody.addEventListener('click', async (event) => {
    const toggle = event.target.closest('.ldva-actions-toggle');
    if (toggle) {
      const menu = toggle.nextElementSibling;
      const wasOpen = !menu.hidden;
      closeAllMenus();
      if (!wasOpen) {
        menu.hidden = false;
        toggle.setAttribute('aria-expanded', 'true');
      }
      return;
    }
    if (event.target.closest('.ldva-actions-item')) {
      closeAllMenus();
    }
    const removeButton = event.target.closest('.ldva-remove');
    if (removeButton) {
      const row = rows[Number(removeButton.dataset.rowIndex)];
      if (!row || !window.confirm(LDVA.strings.removeConfirm)) return;
      removeButton.disabled = true;
      removeButton.textContent = LDVA.strings.removing;
      const body = new URLSearchParams({
        action: 'ldva_remove_video',
        nonce: LDVA.nonce,
        lesson_id: row.lesson_id,
        video_url: row.url || '',
        video_embed: row.embed || '',
        video_shortcode: row.shortcode || ''
      });
      try {
        const response = await fetch(LDVA.ajaxUrl, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body});
        const data = await response.json();
        if (!data.success) throw new Error(data.data?.message || LDVA.strings.error);
        await load();
      } catch (error) {
        window.alert(error.message || LDVA.strings.error);
        removeButton.disabled = false;
        removeButton.textContent = LDVA.strings.removeVideo;
      }
      return;
    }
    const editButton = event.target.closest('.ldva-edit');
    if (editButton) {
      const row = rows[Number(editButton.dataset.rowIndex)];
      if (!row) return;
      editingRow = row;
      editLessonId.value = row.lesson_id;
      modalLesson.textContent = row.lesson;
      editUrl.value = row.url || row.edit_url || '';
      editEmbed.value = row.embed || row.edit_embed || '';
      editShortcode.value = row.shortcode || row.edit_shortcode || '';
      modalMessage.textContent = '';
      modalMessage.className = 'ldva-modal-message';
      modal.hidden = false;
      document.body.classList.add('ldva-modal-open');
      editUrl.focus();
      return;
    }
    const button = event.target.closest('.ldva-copy');
    if (!button) return;
    try {
      await navigator.clipboard.writeText(button.dataset.value);
      const old = button.textContent;
      button.textContent = LDVA.strings.copied;
      setTimeout(() => { button.textContent = old; }, 1200);
    } catch (_) {
      const area = document.createElement('textarea');
      area.value = button.dataset.value;
      document.body.appendChild(area);
      area.select();
      document.execCommand('copy');
      area.remove();
    }
  });
  function closeModal() {
    modal.hidden = true;
    editingRow = null;
    document.body.classList.remove('ldva-modal-open');
  }
  modal.querySelectorAll('[data-close-modal]').forEach((button) => button.addEventListener('click', closeModal));
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (!modal.hidden) closeModal();
    closeAllMenus();
  });
  document.addEventListener('click', (event) => {
    if (!event.target.closest('.ldva-actions')) closeAllMenus();
  });
  saveVideo.addEventListener('click', async () => {
    saveVideo.disabled = true;
    modalMessage.textContent = LDVA.strings.saving;
    modalMessage.className = 'ldva-modal-message';
    const body = new URLSearchParams({
      action: 'ldva_save_video',
      nonce: LDVA.nonce,
      lesson_id: editLessonId.value,
      video_url: editUrl.value.trim(),
      video_embed: editEmbed.value.trim(),
      video_shortcode: editShortcode.value.trim(),
      original_url: editingRow?.url || '',
      original_embed: editingRow?.embed || ''
    });
    try {
      const response = await fetch(LDVA.ajaxUrl, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body});
      const data = await response.json();
      if (!data.success) throw new Error(data.data?.message || LDVA.strings.error);
      modalMessage.textContent = data.data.message || LDVA.strings.saved;
      modalMessage.className = 'ldva-modal-message is-success';
      await load();
      setTimeout(closeModal, 650);
    } catch (error) {
      modalMessage.textContent = error.message || LDVA.strings.error;
      modalMessage.className = 'ldva-modal-message is-error';
    } finally {
      saveVideo.disabled = false;
    }
  });
  document.querySelectorAll('[data-export]').forEach((button) => button.addEventListener('click', () => {
    const allCourses = button.dataset.scope === 'all';
    if (!allCourses && !course.value) {
      course.focus();
      return;
    }
    const params = new URLSearchParams({
      action: 'ldva_export',
      nonce: LDVA.exportNonce,
      course_id: course.value,
      format: button.dataset.export,
      scope: allCourses ? 'all' : 'course',
      search: search.value,
      platform: platform.value,
      status: status.value
    });
    window.location.href = `${LDVA.exportUrl}?${params}`;
  }));
})();
