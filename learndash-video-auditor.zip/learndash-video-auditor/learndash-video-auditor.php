<?php
/**
 * Plugin Name: LearnDash Video Auditor
 * Description: Audita enlaces y códigos embebidos de YouTube y Vimeo en las lecciones de LearnDash.
 * Version: 2.8.3
 * Author: Codex
 * Text Domain: ld-video-auditor
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

define('LDVA_VERSION', '2.8.3');
define('LDVA_FILE', __FILE__);
define('LDVA_DIR', plugin_dir_path(__FILE__));
define('LDVA_URL', plugin_dir_url(__FILE__));

require_once LDVA_DIR . 'includes/class-ldva-scanner.php';
require_once LDVA_DIR . 'includes/class-ldva-exporter.php';
require_once LDVA_DIR . 'includes/class-ldva-admin.php';

add_action('plugins_loaded', static function () {
    LDVA_Admin::instance();
});
